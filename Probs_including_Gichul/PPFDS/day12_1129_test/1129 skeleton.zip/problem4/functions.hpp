#include <vector>
#include <string>
#include <queue>

using namespace std;


int function4(vector<pair<int, int>> &requests) {
    // Fill this function
}

// If you need to construct another functions, write and use here. 
// However, you can not use those functions in main.cpp.
// Submit functions.hpp file.

// compile command: g++ -o main main.cpp
// execute command: 
//              ./main "1 4 2 6 5 9"