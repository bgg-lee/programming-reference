#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

long long function3(int n, int times[], int size) {
    //Write your code
}

// Feel free to construct functions you need. 
// Submit functions.h file.

// compile command: g++ -o main main.c
// execute command: 
//             ./main n "times"
//             ./main 6 "7 10" # answer: 28