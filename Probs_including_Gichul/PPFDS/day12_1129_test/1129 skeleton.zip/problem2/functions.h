#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_CUSTOMERS 100
#define MAX_SUSHI_TYPES 1000


void function2(int N, int M, int orders[][1000], int* sushi_sequence, int* result) {
    
}
// Feel free to construct functions you need. 
// Submit functions.h file.

// compile command: g++ -o main main.c
// execute command: 
//             ./main "3 5" "1 6" "2 3 5" "1" "3 2 1 4 5"