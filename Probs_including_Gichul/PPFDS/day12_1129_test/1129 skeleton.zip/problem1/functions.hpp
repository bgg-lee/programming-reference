#include <vector>
#include <string>
#include <queue>

using namespace std;


int function1(vector<vector<int>> jobs) {

}

// If you need to construct another functions, write and use here. 
// However, you can not use those functions in main.cpp.
// Submit functions.hpp file.

// compile command: g++ -o main main.cpp
// execute command: 
//              ./main "0 3 1 9 2 5"