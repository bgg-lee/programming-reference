#include <stdlib.h>
#include <string.h>

int function1(char word1[], char word2[]) {
    //Write your code
}

// Feel free to construct functions you need. 
// Submit functions.h file.

// compile command: g++ -o main main.c
// execute command: 
//             ./main "geek" "gesek"
//             ./main "cat" "cut"
//             ./main "sunday" "saturday"