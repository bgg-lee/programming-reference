#include <vector>
using namespace std;

int function2(const std::vector<int>& arr) {
    // Fill this function
}

// If you need to construct another functions, write and use here. 
// However, you can not use those functions in main.cpp.
// Submit functions.hpp file.

// compile command: g++ -o main main.cpp
// execute command: 
//              ./main "2 1 5 6 2 3"
//              ./main "2 4"