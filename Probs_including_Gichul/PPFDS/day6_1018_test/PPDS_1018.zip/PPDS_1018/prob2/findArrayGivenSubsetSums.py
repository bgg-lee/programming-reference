def recoverArray(n: int, sums: list[int]) -> list[int]:
    
    """
    Write your code
    """

    # sums.sort() # You can use this if you want
    
    return 



if __name__ == "__main__":
    
    '''
    Test your code if you want
    '''
