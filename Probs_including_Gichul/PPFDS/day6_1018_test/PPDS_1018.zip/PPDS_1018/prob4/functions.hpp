#include <vector>

using namespace std;

int reversePairs(vector<int>& nums) {
    // Fill this function
}

// If you need to construct another functions, write and use here. 
// However, you can not use those functions in main.cpp.
