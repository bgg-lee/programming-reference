def subset(lst_in: list[int]) -> list[list[int]]:

    """
    Write your code
    """
    return 


if __name__ == "__main__":
    
    '''
    Test your code if you want
    '''