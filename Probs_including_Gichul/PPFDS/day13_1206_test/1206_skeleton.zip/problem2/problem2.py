def problem2(price: list[int]) -> int:

    return 


if __name__ == "__main__":
    
    pass