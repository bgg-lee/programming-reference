def problem1(n : int, edges : list[list[int]]) -> int:

    return 

if __name__ == "__main__":
    
    pass
