#include <vector>
using namespace std;

int function4(const std::vector<int>& arr) {
    // Fill this function
}

// If you need to construct another functions, write and use here. 
// However, you can not use those functions in main.cpp.