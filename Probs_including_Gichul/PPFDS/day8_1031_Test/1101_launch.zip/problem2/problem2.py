def problem2(grid: list[list[int]]) -> int:
    
    # Write your code

    pass

if __name__ == "__main__":
    
    # Test your code
    
    pass
