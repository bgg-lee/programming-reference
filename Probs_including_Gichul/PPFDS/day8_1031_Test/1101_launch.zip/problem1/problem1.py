import sys
sys.setrecursionlimit(10**6)  # setting recursion limit to prevent stack overflow

def problem1(N: int, M: int, V: list[list[int]]) -> int:
    
    # Write your code

    pass

if __name__ == "__main__":
    
    # Test your code
    
    pass