int climbStairs(int n) {
    //Write your code
}