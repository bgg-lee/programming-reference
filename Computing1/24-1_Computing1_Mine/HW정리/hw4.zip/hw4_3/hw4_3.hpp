#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <map>
#include <iostream>
#include <random>

using namespace std;

class KNN {
public:
    KNN(int k, string metric);
    void train(const vector<vector<double>>& X, const vector<int>& y);
    int infer(const vector<double>& x) const;
private:
    int k;
    string metric;
    vector<vector<double>> train_X;
    vector<int> train_y;

    double euclideanDistance(const vector<double>& a, const vector<double>& b) const;
    double cosineSimilarity(const vector<double>& a, const vector<double>& b) const;
};

KNN::KNN(int k, string metric) : k(k), metric(metric) {}

void KNN::train(const vector<vector<double>>& X, const vector<int>& y) {
    train_X = X;
    train_y = y;
}

// To implement
int KNN::infer(const vector<double>& x) const {
}

// Euclidean distance function(To implement)
double KNN::euclideanDistance(const vector<double>& a, const vector<double>& b) const {
}

// Cosine similarity function(To implement)
double KNN::cosineSimilarity(const vector<double>& a, const vector<double>& b) const {
}