#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include "hw4_3.hpp"

// Function to read a CSV file and return the data as a vector of vector of doubles
vector<vector<double>> readCSV(const string& filename) {
    ifstream file(filename);
    vector<vector<double>> data;
    string line;
    while (getline(file, line)) {
        stringstream lineStream(line);
        string cell;
        vector<double> row;
        while (getline(lineStream, cell, ',')) {
            row.push_back(stod(cell));
        }
        data.push_back(row);
    }
    return data;
}

int main() {
    // Read the dataset (excluding the last column for features)
    vector<vector<double>> dataset = readCSV("iris.csv");
    vector<vector<double>> X;
    vector<int> y;

    for (const auto& row : dataset) {
        vector<double> features(row.begin(), row.end() - 1);
        int label = static_cast<int>(row.back());
        X.push_back(features);
        y.push_back(label);
    }
    // Create object & training
    // arg1: k of knn, arg2: “E” for euclidean dist, “C” for cos sim
    KNN knn(3, "E");
    knn.train(X, y);

    // Test one example from the dataset
    vector<double> test_sample = {5.1,3.5,1.4,0.2};
    int predicted_label = knn.infer(test_sample);

    cout << "Predicted label: " << predicted_label << endl;

    return 0;
}