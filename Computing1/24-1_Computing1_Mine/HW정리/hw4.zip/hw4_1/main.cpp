#include "hw4_1.hpp"

int main(){
    int n = 5;
    vector<string> city_list = {"A","B","C","D","E"};
    vector<vector<int>> distance(n, vector<int>(n, INF));
    vector<vector<int>> predecessor(n, vector<int>(n));
    vector<vector<int>> vertex_edge = {
        {0,1,3},
        {0,2,8},
        {0,4,-4},
        {1,3,1},
        {1,4,7},
        {2,1,4},
        {3,0,2},
        {3,2,-5},
        {4,3,6}
    };

    initializeGraph(distance, predecessor, vertex_edge);
    DistanceMatrix(distance, predecessor);
    int start=0, end=3;
    printPath(predecessor, start, end, city_list);
    NegCycleDetection(distance);
}
