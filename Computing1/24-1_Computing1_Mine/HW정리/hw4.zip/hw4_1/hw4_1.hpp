#include <iostream>
#include <vector>
#include <limits>
#include <string.h>

using namespace std;

const int INF = 999;

void initializeGraph(vector<vector<int>>& distance, vector<vector<int>>& predecessor, vector<vector<int>>& vertex_edge) {
}

void DistanceMatrix(vector<vector<int>>& distance, vector<vector<int>>& predecessor) {
}

void printGraph(const vector<vector<int>>& distance) {
    int n = distance.size();
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (distance[i][j] == INF) cout << "INF ";
            else cout << distance[i][j] << " ";
        }
        cout << endl;
    }
}

void printPath(const vector<vector<int>>& predecessor, int start, int end, vector<string> label) {
}

void NegCycleDetection(const vector<vector<int>>& distance){
}