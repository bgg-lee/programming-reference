#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

double loss(const std::vector<std::vector<double>>& X, const std::vector<double>& y, const std::vector<double>& w) {
    int m = X.size();  // Number of samples
    double total_cost = 0.0;
    for (int i = 0; i < m; ++i) {
        double prediction = 0.0;
        for (int j = 0; j < X[i].size(); ++j) {
            prediction += w[j] * X[i][j];
        }
        double error = prediction - y[i];
        total_cost += error * error;
    }
    return total_cost / (2 * m);
}

// (To implement) - This function should return the weights of linear model as a vector
std::vector<double> gradientDescent(const std::vector<std::vector<double>>& X, const std::vector<double>& y, std::vector<double>& w, double alpha, int num_iters) {
}