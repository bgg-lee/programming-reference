#include "hw4_4.hpp"
#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <sstream>
#include <utility>

// read X
vector<vector<double>> readCSV(const string& filename) {
    ifstream file(filename);
    vector<vector<double>> data;
    string line;
    while (getline(file, line)) {
        stringstream lineStream(line);
        string cell;
        vector<double> row;
        while (getline(lineStream, cell, ',')) {
            row.push_back(stod(cell));
        }
        data.push_back(row);
    }
    return data;
}

// read y
vector<double> readLabels(const string& filename) {
    ifstream file(filename);
    vector<double> labels;
    string line;
    while (getline(file, line)) {
        labels.push_back(stod(line));
    }
    return labels;
}

int main() {
    // data load
    vector<vector<double>> X = readCSV("data.csv");
    vector<double> y = readLabels("label.csv");

    //train test split
    int n_train = X.size()*0.8;
    int n_test = X.size()-n_train;

    vector<vector<double>> X_train;
    vector<double> y_train;
    for(int i=0;i<n_train;i++){
        X_train.push_back(X[i]);
        y_train.push_back(y[i]);
    }
    vector<vector<double>> X_test;
    vector<double> y_test;
    for(int i=n_train;i<X.size();i++){
        X_test.push_back(X[i]);
        y_test.push_back(y[i]);
    }

    // Weight, hyperparameter initialize
    vector<double> w(X[0].size(), 0.0);
    double alpha = 0.01;
    int num_iters = 1000;

    // train
    w = gradientDescent(X_train, y_train, w, alpha, num_iters);

    // infer
    double mse = 0;
    for(int i=0;i<n_test;i++){
        double pred=0;
        for(int j=0;j<X[0].size();j++){
            pred+=w[j]*X_test[i][j];
        }
        mse+=pow(y_test[i]-pred,2);
    }
    cout << "MSE:" << mse/n_test << endl;

    return 0;
}