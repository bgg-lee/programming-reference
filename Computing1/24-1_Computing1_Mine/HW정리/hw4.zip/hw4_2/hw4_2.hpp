#include <iostream>
using namespace std;

const string RED = "RED";
const string BLACK = "BLACK";

class Node {
public:
    int data;
    string color;
    Node *left, *right, *parent;
    Node(int data) : data(data), color(RED), left(nullptr), right(nullptr), parent(nullptr) {}
};

class RBTree {
private:
    Node *root;

protected:
    void rotateLeft(Node *root, Node *x);
    void rotateRight(Node *root, Node *x);
    void fixInsertRBTree(Node *root, Node *pt);
    Node* BSTInsert(Node *root, Node *pt);

public:
    RBTree() { root = nullptr; }
    void insert(const int &n);
    void inorder();
    void inorderHelper(Node *node);
    void search(const int &key);

};

void RBTree::rotateLeft(Node *root, Node *x) {
    Node *y = x->right;
    x->right = y->left;
    if (x->right != nullptr)
        x->right->parent = x;

    y->parent = x->parent;
    if (x->parent == nullptr)
        this->root = y;
    else if (x == x->parent->left)
        x->parent->left = y;
    else
        x->parent->right = y;

    y->left = x;
    x->parent = y;
}

void RBTree::rotateRight(Node *root, Node *x) {
    Node *y = x->left;
    x->left = y->right;
    if (x->left != nullptr)
        x->left->parent = x;

    y->parent = x->parent;
    if (x->parent == nullptr)
        this->root = y;
    else if (x == x->parent->left)
        x->parent->left = y;
    else
        x->parent->right = y;

    y->right = x;
    x->parent = y;
}

// To implement
void RBTree::fixInsertRBTree(Node *root, Node *pt) {
}

void RBTree::insert(const int &data) {
    Node *pt = new Node(data);
    root = BSTInsert(root, pt);
    fixInsertRBTree(root, pt);
}

void RBTree::inorder() { inorderHelper(root); }

void RBTree::inorderHelper(Node *root) {
    if (root == nullptr)
        return;
    inorderHelper(root->left);
    cout << root->data << "-";
    inorderHelper(root->right);
}

Node* RBTree::BSTInsert(Node* root, Node *pt) {
    if (root == nullptr)
        return pt;

    if (pt->data < root->data) {
        root->left = BSTInsert(root->left, pt);
        root->left->parent = root;
    } else if (pt->data > root->data) {
        root->right = BSTInsert(root->right, pt);
        root->right->parent = root;
    }

    return root;
}

void RBTree::search(const int &key){
    Node* current = root;
    int height = 0;
    while (current != nullptr) {
        if (key == current->data){
            cout << height;
            return;
        }
        else if (key < current->data){
            current = current->left;
            height++;
        }
        else{
            current = current->right;
            height++;
        }
    }
    cout << "Not exist";
}