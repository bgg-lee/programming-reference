#include <iostream>
#include <string.h>

using namespace std;

// Implement definition of all classes and the member functions in this file.

class Container{

};

class Box: public Container{

};

class PaperBox: public Box{

};

class PlasticBox: public Box{

};

class Bag: public Container{

};

class Carrier: public Container{

};