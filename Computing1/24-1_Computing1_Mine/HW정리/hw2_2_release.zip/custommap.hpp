#include <iostream>
#include <string>
#include <functional>

using namespace std;

template < > //Fill in the empty templates and implement the definition of the class and each member functions
class TreeNode {

};

template < > //Fill in the empty templates and implement the definition of the class and each member functions
class CustomMap {
    
};
