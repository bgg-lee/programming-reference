#include <iostream> 
#include <queue>
#include <vector>

#include "functions.hpp"

using namespace std; 

int minDistance(vector<vector<int>>& points) {
    return -1;
}