#include <iostream> 
#include <vector>
using namespace std; 


int minDistance(vector<vector<int>>& points);