#include <iostream>
#include <vector>

using namespace std;

void flightRoute(const int n, const int m, const vector<vector<int>> & route_info);