#include <iostream>
#include <vector>
#include <algorithm>

#include "functions.hpp"

using namespace std;

long coinCombinations(int n, int sum, vector<int> & coins)
{
 
    return -1;
}