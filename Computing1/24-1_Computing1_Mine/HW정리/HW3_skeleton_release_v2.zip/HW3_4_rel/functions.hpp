#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

long coinCombinations(int n, int x, vector<int> & coins);