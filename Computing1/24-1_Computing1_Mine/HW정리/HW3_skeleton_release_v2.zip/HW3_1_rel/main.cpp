#include <iostream> 
#include <climits> 
#include <queue>
#include <cmath>
using namespace std; 

#include "functions.hpp"
  
// Driver program to test above functions 
int main() 
{ 
    MaxHeap h; 
    h.enqueue(10);
    h.enqueue(30);
    h.enqueue(40);    
    h.enqueue(500);    
    h.enqueue(80);
    h.dequeue();
    h.printHeap();

    cout << "Maximum value of the heap: " << h.getMax()->val << endl; 

    return 0; 
} 