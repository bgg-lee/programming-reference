#include <iostream> 
#include <climits> 
#include <queue>
#include <cmath>

#include "functions.hpp"

using namespace std; 


MaxHeap::MaxHeap(){
        root = nullptr;        
}  

Node * MaxHeap::getMax(){
    return root;
}

void MaxHeap::printHeap(){
    Node * currNode = root;
    queue<Node*> q;

    q.push(root);
    std::cout << "Print Heap: ";
    while (!q.empty() && q.front()){
        std::cout << q.front()->val << " ";
        if (q.front()->left){
            q.push(q.front()->left);
        }

        if (q.front()->right){
            q.push(q.front()->right);
        }

        q.pop();
    }
    std::cout << std::endl;
}

void MaxHeap::swap(Node * a, Node * b){
    int temp = a->val;
    a->val = b->val;
    b->val = temp;
}


// Inserts a new key 'k' 
void MaxHeap::enqueue(int k) 
{ 
    
} 

// Removes the root node and heapify
void MaxHeap::dequeue(){
    
}
