#include "WordCounter.h"

// Fill in here