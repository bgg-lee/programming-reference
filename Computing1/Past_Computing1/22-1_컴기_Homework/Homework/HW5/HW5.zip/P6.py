def P6(input_filename: str, out_filename: str): 
    ##### Write your Code Here #####

    ##### End of your code #####