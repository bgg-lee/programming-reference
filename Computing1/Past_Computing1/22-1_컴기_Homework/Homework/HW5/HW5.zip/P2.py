def P2(filename: str) -> list:        
    ##### Write your Code Here #####

    ##### End of your code #####