def P5(filename: str) -> int:        
    ##### Write your Code Here #####

    ##### End of your code #####