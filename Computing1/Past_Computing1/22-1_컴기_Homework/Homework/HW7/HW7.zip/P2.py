def P3(s: str) -> int:
    ### Modify code here ###
    
    ### End of your code ###