from typing import List
def P4(matrix: List[List[int]], target: int) -> (int, int):        
    ##### Write your Code Here #####    
    
    ##### End of your code #####