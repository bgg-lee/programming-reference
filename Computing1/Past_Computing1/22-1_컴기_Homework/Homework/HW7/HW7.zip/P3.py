def P4(info: list) -> str:        
    ##### Write your Code Here #####    
    
    ##### End of your code #####