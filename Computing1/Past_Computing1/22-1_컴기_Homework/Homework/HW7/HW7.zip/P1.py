def P1(n: int) -> bool:        
    ##### Write your Code Here #####    
    
    ##### End of your code #####