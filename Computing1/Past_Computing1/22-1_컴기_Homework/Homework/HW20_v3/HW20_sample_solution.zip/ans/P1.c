#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
    int N = atoi(argv[1]);

    // YOUR CODE HERE
    
    for(int i = 1; i<= N; i++){
        
        for(int j = 0; j < N-i; j++){
            printf("%c", ' ');
        }
        printf("%c", '*');
        
        if (i == 1){
            printf("%c", '\n');
            continue;
        }

        for(int j = 0; j < 2*i-3; j++){
            if (i == N){
                printf("%c", '*');
            } else {
                printf("%c", ' ');
            }

        }
        printf("%c", '*');
        for(int j = 0; j < N-i; j++){
            printf("%c", ' ');
        }
        printf("%c", '\n');
    }
    return 0;
}
