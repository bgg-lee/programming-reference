#include <stdio.h> 
#include <string.h> 
int main(int argc, char *argv[]){ 
    FILE *input_file; 
    FILE *output_file; 
    char *input_filename = argv[1]; 
    char *output_filename = argv[2]; 
    
    input_file = fopen(input_filename, "r"); 
    output_file = fopen(output_filename, "w"); 
    int num = 0;
    
    //Read input file, and get the number
    while(fscanf(input_file, "%d", &num) != EOF){ 
        
        // Write the front part of the line
        fprintf(output_file, "%d = ", num); 
        
        // Convert to binary number
        int num_bin = 0;
        int i = 1;
        while (num > 1){
            num_bin += (num % 2)*i;
            num = num / 2;
            i *= 10;            
        }
        num_bin += i;
        // Write the binary number
        fprintf(output_file, "%d\n", num_bin);         
    } 
    
    fclose(input_file); 
    fclose(output_file); 
    
    return 0; 
}