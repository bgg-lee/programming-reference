#include <stdio.h> 

int main(int argc, char *argv[]){        
    FILE *file; 
    char *filename = argv[1]; 
    file = fopen(filename, "r"); 
    int i = 0;
    char str[300];    
    
    
    // You can use fscanf, 
    // this automatically ignores white space and new line etc.    
    while(fscanf(file, "%s", str) != EOF){
        int j = 0;
        while (str[j] != '\0'){
            printf("%c", str[j]);
            
            j += 1;
        }        
    }     
    //New line for better layout
    printf("\n");
    
     /*
    // You can also use fgets function
    // to read the file line by line
    char ans[300];
    while(fgets(str, 300, file)){
        int j = 0;
        while (str[j] != '\0'){
            if (str[j] != ' ' && str[j] != '\n'){
                ans[i] = str[j];
                i += 1;
            }
            j += 1;
        }
    }
    ans[i] = '\0';
    printf("%s\n", ans);    
    */
    // C string library could also be used.
    fclose(file); 
    
    return 0; 
}