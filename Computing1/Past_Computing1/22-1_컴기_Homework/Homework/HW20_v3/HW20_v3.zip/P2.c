#include <stdio.h> 

int main(int argc, char *argv[]){
    char *input_filename = argv[1]; // name of input file
    // YOUR CODE HERE

    
    return 0; 
}