class Calculator:
    def __init__(self):
        #write your code below

    def digit(self,num):
        #write your code below


    def plus(self):
        #write your code below


    def minus(self):
        #write your code below


    def clear(self):
        #write your code below


    def equal(self):
        #write your code below
