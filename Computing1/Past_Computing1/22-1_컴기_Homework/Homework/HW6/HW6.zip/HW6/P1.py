class Country:
    def __init__(self, name, population, area):

        # write your code below


    
    def is_larger(self, other):

        # write your code below

    
    def population_density(self):

        # write your code below