from P1 import Country # Do Not Modify

class Continent:
    def __init__(self, name, countries):

        # write your code below

        
    def total_population(self):

        # write your code below




