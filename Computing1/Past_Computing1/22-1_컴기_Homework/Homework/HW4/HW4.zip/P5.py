def P5(dct: dict) -> list:
    ### Write code here ###


    return

    ### End of your code ###     
