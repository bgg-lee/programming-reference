def P10(words: set, query_word: str) -> bool:
    ### Write code here ###
    

    return 

    ### End of your code ###     
