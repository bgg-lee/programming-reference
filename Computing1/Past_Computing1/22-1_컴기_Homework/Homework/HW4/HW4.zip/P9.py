def P9(dct1: dict, dct2: dict) -> int: 
    ### Write code here ###
    
            
    return 

    ### End of your code ###    
