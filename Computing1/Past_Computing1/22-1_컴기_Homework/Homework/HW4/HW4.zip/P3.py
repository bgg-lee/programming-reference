def P3(dct: dict) -> int:
    ### Write code here ###

    return 

    ### End of your code ###     
