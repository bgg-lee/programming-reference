def P1(lst: list) -> set:
    ### Write code here ###


    return 

    ### End of your code ###     
