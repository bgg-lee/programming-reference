def P6(dct1: dict, dct2: dict) -> dict:
    ### Write code here ###

    return 

    ### End of your code ###     
