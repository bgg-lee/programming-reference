def P4(dct: dict) -> str:
    ### Write code here ###


    return 

    ### End of your code ###     
