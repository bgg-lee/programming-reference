def P2(lst1: list, lst2: list) -> set:
    ### Write code here ###
    
 

    return 

    ### End of your code ###     
