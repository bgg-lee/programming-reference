def P8(dct: dict) -> bool:
    ### Write code here ###
        
    return 

    ### End of your code ###    
