#include <stdio.h>
#include <stdlib.h>

int P4(int n);


int P4(int n){
    // write your code below

}

// DO NOT MODIFY BELOW!
int main(int argc, char* argv[]){
    int n = atoi(argv[1]);
    int ans = P4(n);

    printf("%d\n", ans);

    return 0;
}