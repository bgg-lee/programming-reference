def P2(Order: str, S: str) -> str:

    ### Write code here ###


    ### End of your code ###  