def P5(A: list, B: list) -> int:
    
    ### Write code here ###

    
    ### End of your code ###  
