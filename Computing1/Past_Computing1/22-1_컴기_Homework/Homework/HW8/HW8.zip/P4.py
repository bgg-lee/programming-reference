from typing import List
def P4(matrix:List[list]) -> List[list]:

    ### Write code here ###

    
    ### End of your code ###  