def P3(lst: list) -> list:

    ### Write code here ###

    
    ### End of your code ###  