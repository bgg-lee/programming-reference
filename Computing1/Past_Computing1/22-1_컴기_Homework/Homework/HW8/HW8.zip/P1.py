def P1(num_list: list) -> int:

    ### Write code here ###


    
    ### End of your code ###  