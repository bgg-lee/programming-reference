"""
**Instruction**
Please see instruction document.
"""
from BST_Helper import *
def P3(root: TreeNode, val: int) -> TreeNode:    
    ##### Write your Code Here #####

   
    
    return root
    ##### End of your code #####
