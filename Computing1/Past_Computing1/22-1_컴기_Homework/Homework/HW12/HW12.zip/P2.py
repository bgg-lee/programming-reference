def P2(nums: list) -> int:

    ### Write code here ###

    
    ### End of your code ###  