def P3(A: list, B: list) -> int:

    ### Write code here ###

    
    ### End of your code ###  
  