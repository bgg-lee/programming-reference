def P1(nums: list, k: int) -> bool:

    ### Write code here ###

    
    ### End of your code ###