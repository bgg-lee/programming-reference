from typing import List
def P2(n: int, edges: List[tuple]) -> int:
    ##### Write your Code Here #####
                           
    return 
    ##### End of your code #####