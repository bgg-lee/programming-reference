from typing import List
def P3(image: List[list]) -> int:
    ##### Write your Code Here #####
    
    return 
    ##### End of your code #####