from typing import List
def P4(world: List[list]) -> int:
    ##### Write your Code Here #####
    
    return 
    ##### End of your code #####