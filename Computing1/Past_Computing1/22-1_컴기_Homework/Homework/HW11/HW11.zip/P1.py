from typing import List
def P1(rooms: List[list]) -> int:
    ##### Write your Code Here #####
    
    return
    ##### End of your code #####