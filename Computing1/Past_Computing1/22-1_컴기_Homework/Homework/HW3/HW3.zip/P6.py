from typing import List
def P6(n1: int, n2: int) -> List[int]:
    ans_list = []
    ### Modify code here ###

    ### End of your code ###
    return ans_list

