from typing import List
def P4(word_num_list: List[list]) -> list:
    ans_list = []
    ### Modify code here ###
    
    ### End of your code ###  
    return ans_list
    