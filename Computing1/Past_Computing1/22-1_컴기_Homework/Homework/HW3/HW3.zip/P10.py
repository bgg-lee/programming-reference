def P10(rat_1: list, rat_2: list, measure_day: int) -> bool:  
    is_greater = 0  
    ##### Modify code Here #####

    ##### End of your code #####
    return is_greater