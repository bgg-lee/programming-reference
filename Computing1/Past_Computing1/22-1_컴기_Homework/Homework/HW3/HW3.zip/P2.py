def P2(L1: list, L2: list, L3: list) -> int:
    ans = 0
    ### Modify code here ###

    ### End of your code ###
    return ans