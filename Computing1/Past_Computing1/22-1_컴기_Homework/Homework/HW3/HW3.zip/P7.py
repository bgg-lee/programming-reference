def P7(L1: list) -> list:
    ans_list = []
    ##### Write your Code Here #####

    ##### End of your code #####
    return ans_list