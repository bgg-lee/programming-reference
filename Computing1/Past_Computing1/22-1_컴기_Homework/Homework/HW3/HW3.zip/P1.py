from typing import List
def P1(num_list: List[int]) -> List[int]:
    ### Modify code here ###

    ### End of your code ###
    return num_list
