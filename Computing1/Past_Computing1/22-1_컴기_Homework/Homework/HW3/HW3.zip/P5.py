from typing import List
def P5(alphabet_list: List[str]) -> int:
    idx = 0
    ### Modify code here ###
    
    ### End of your code ###  
    return idx
