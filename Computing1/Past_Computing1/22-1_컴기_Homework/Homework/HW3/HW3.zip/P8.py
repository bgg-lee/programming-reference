from typing import List
def P8(num_list: List[float]):
    ans_list = []
    ##### Modify code Here #####

    ##### End of your code #####
    return ans_list
    

