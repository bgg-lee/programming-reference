def P9(nested_list: list) -> list:    
    ans_list = []
    ##### Modify code Here #####

    ##### End of your code #####
    return ans_list

