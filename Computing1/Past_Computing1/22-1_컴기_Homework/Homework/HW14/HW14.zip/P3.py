def P3(nums:list)->set:
    # write your code below
  
    return