def P4(num:int) -> int:
    # write your code below

    return