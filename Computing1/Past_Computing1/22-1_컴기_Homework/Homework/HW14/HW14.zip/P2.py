def P2(num:int)->int:
    # write your code below
       
    return 