def P1(n: int) -> bool:
    # write your code below
  
    return 