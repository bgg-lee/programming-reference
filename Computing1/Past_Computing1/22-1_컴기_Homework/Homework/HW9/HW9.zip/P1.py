def P1(parentheses: str) -> bool:  
    ##### Write your Code Here #####      
 
    return True
    ##### End of your code #####

