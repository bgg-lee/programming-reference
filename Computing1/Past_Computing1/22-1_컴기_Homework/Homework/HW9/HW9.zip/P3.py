from linked_list_helper import ListNode

def P3(head: ListNode) -> ListNode: 
    ##### Write your Code Here #####
    
    return None
    ##### End of your code #####
