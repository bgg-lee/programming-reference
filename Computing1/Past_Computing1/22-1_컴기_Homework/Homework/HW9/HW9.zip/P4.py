from linked_list_helper import ListNode

def P4(num1: ListNode, num2: ListNode) -> ListNode: 
    ##### Write your Code Here #####
    
    
    return None
    ##### End of your code #####