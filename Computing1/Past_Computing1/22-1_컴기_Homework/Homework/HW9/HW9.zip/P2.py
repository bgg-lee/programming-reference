def P2(stock_price: list) -> list:        
    ##### Write your Code Here #####


    return []
    ##### End of your code #####

