#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <map>
#include <vector>

#include "functions.hpp"

using namespace std;

void ParseCSV(const std::string & filename, std::map<int, std::string> & header_cols, map<std::string, vector<std::string>> & data_map){

    
}

// Sum all elements in the column  
int SumColumn(const std::string &column_name, map<std::string, vector<std::string>> &data_map){

    return -1;
}


double FilterMostFrequentAvg(const std::string &key_col, std::string &value_col, map<std::string, vector<std::string>> &data_map){

    return -1;
}


void SumTwoColumns(std::string &value_col1, std::string &value_col2, const std::string & out_filename, std::map<int, std::string> & header_cols, map<std::string, vector<std::string>> & data_map){

}